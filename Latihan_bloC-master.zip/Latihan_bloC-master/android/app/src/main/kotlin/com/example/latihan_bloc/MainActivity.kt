package com.example.latihan_bloc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
